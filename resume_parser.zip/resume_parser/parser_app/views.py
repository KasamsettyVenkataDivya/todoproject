import pdfplumber
import docx2txt
import re
import json
from collections import Counter

from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.urls import path
from django.core.files.storage import default_storage

# Sample skills list (can be replaced with a more extensive list or ML-based extraction)
SKILLS_DB = {"Python", "Java", "C++", "Django", "Flask", "Machine Learning", "SQL", "React", "AWS"}

def extract_text_from_pdf(pdf_path):
    with pdfplumber.open(pdf_path) as pdf:
        return " ".join([page.extract_text() for page in pdf.pages if page.extract_text()])

def extract_text_from_docx(docx_path):
    return docx2txt.process(docx_path)

def extract_email(text):
    match = re.search(r"[\w\.-]+@[\w\.-]+", text)
    return match.group(0) if match else "Not found"

def extract_name(text):
    lines = text.split("\n")
    return lines[0] if lines else "Not found"

def extract_skills(text):
    words = set(re.findall(r"\b\w+\b", text))
    return list(SKILLS_DB.intersection(words))

def calculate_score(jd_skills, resume_skills):
    matched_skills = set(jd_skills) & set(resume_skills)
    total_score = (len(matched_skills) / len(jd_skills)) * 100 if jd_skills else 0
    return round(total_score, 2), list(matched_skills)

@csrf_exempt
def evaluate_resume(request):
    if request.method == 'POST' and request.FILES:
        jd_text = request.POST.get("jd_text", "")
        resume_file = request.FILES["resume"]
        
        file_path = default_storage.save(resume_file.name, resume_file)
        
        if resume_file.name.endswith(".pdf"):
            resume_text = extract_text_from_pdf(file_path)
        elif resume_file.name.endswith(".docx"):
            resume_text = extract_text_from_docx(file_path)
        else:
            return JsonResponse({"error": "Unsupported file format"}, status=400)
        
        name = extract_name(resume_text)
        email = extract_email(resume_text)
        jd_skills = extract_skills(jd_text)
        resume_skills = extract_skills(resume_text)
        score, matched_skills = calculate_score(jd_skills, resume_skills)

        return render(request, 'upload.html', {
            "name": name,
            "email": email,
            "resume_skills": resume_skills,
            "jd_skills": jd_skills,
            "matched_skills": matched_skills,
            "total_score": score
        })
    return render(request, 'upload.html')

