from django.urls import path
from django.shortcuts import render
from .views import evaluate_resume  # Only import what is needed

urlpatterns = [
    path('upload/', evaluate_resume, name='upload_page'),  # Change '' to 'upload/'
    path('evaluate/', evaluate_resume, name='evaluate_resume')
]

